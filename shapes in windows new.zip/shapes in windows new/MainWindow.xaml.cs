﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace sample
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            DataContext = this;
        }

        private double heightval = 0;
        public double HeightOfRectangle
        {
            get => heightval;
            set
            {
                heightval = value;
                funToCreateRect();
                funToCreateEllipse();
            }
        }

        private double widthval = 0;
        public double WidthOfRectangle
        {
            get => widthval;
            set
            {
                widthval = value;
                funToCreateRect();
                funToCreateEllipse();
            }
        }
        Rectangle? rect = null;

        public void funToCreateRect()
        {
            if (rect == null)
            {
                rect = new Rectangle();
                rect.Width = widthval;
                rect.Height = heightval;

                //properties to fill out the rectangle
                SolidColorBrush fillbrush = new SolidColorBrush();
                fillbrush.Color = Colors.DarkBlue;
                fillbrush.Opacity = .5;
                rect.Fill = fillbrush;

                //properties of the border of the shape
                SolidColorBrush outlinebrush = new SolidColorBrush();
                outlinebrush.Color = Colors.Black;
                rect.StrokeThickness = 1;
                rect.Stroke = outlinebrush;

                //CanvasArea.Children.Add(rect);
            }
            else
            {
                rect.Width = WidthOfRectangle;
                rect.Height = HeightOfRectangle;
            }
        }

        //when the user clicks Rectangle button
        public void ClickToCreateRect(object sender, RoutedEventArgs e)
        {
            //exception handling if user tries to draw rectangle without providing input
            // Null Reference Exception
            try
            {
                Canvas.SetLeft (rect, (CanvasArea.ActualWidth - rect.Width) / 2);
                Canvas.SetTop (rect, (CanvasArea.ActualHeight - rect.Height) / 2);
                CanvasArea.Children.Add(rect);

                var totalAreaRect = WidthOfRectangle * HeightOfRectangle;
                areaBlock.Text = totalAreaRect.ToString();

                var perimeterOfRect = 2 * (widthval + heightval);
                periBlock.Text = perimeterOfRect.ToString();
            }
            catch(NullReferenceException)
            {
                MessageBox.Show("Please provide specific input.");
            }
            catch(ArgumentException)
            {
                MessageBox.Show("Something is wrong. Make sure that the canvas is empty.");
            }
        }
        
        Ellipse? ellipse = null;
        public void funToCreateEllipse()
        {
            if (ellipse == null)
            {
                ellipse = new Ellipse();

                ellipse.Width = widthval;
                ellipse.Height = heightval;

                //properties to fill out an ellipse
                SolidColorBrush fillbrush = new SolidColorBrush();
                fillbrush.Color = Colors.Lime;
                fillbrush.Opacity = .5;
                ellipse.Fill = fillbrush;

                //the border of an ellipse
                SolidColorBrush outlinebrush = new SolidColorBrush();
                outlinebrush.Color = Colors.Black;
                ellipse.StrokeThickness = 1;
                ellipse.Stroke = outlinebrush;
            }
            else
            {
                ellipse.Width = WidthOfRectangle;
                ellipse.Height = HeightOfRectangle;
            }
        }

        //when the user clicks Circle button
        public void ClickToCreateEllipse(object sender, RoutedEventArgs e)
        {
            //exception handling if user tries to draw circle without providing input
            // Null Reference Exception
            try
            {
                Canvas.SetLeft (ellipse, (CanvasArea.ActualWidth - ellipse.Width) / 2);
                Canvas.SetTop (ellipse, (CanvasArea.ActualHeight - ellipse.Height) / 2);
                CanvasArea.Children.Add (ellipse);
                var totalAreaEllipse = Math.PI * (WidthOfRectangle * HeightOfRectangle);
                areaBlock.Text = totalAreaEllipse.ToString();
            }
            catch(NullReferenceException)
            {
                MessageBox.Show("Please provide specific input.");
            }
            catch(ArgumentException)
            {
                MessageBox.Show("Something is wrong. Make sure that the canvas is empty.");
            }
        }

        //function to remove the shape from canvas on mouse right click
        private void removeTheShape(object sender, MouseButtonEventArgs e)
        {
            Point pt = e.GetPosition((Canvas)sender);
            HitTestResult result = VisualTreeHelper.HitTest(CanvasArea, pt);

            if(result != null)
            {
                CanvasArea.Children.Remove(result.VisualHit as Shape);
            }
        }
    }
}
